package RPG;

public class teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Teste para fazer pull
	}

}
